#include <cstdlib>
#include <unistd.h>
#include <fcntl.h>
#include <string>
#include <android-base/properties.h>
#include <android-base/logging.h>

#include "property_service.h"
#include "util.h"
#include "log.h"

namespace android {
namespace init {

void vendor_load_properties() {
    LOG(INFO) << __func__ << "\n";
    property_set("ro.om_imx8.variant", "variant1");
}
}  // namespace init
}  // namespace android
