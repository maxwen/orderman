#define LOG_TAG "om_service"
#include <utils/Log.h>

int main(int argc, const char* argv[]) {
    ALOGD("Its alive");
}
