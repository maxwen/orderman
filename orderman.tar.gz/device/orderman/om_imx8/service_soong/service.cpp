#define LOG_TAG "om_service"
#include <utils/Log.h>

int main(int argc, const char* argv[]) {
    ALOGD("Its alive");
#ifdef TARGET_VENDOR_FLAG
#error "TARGET_VENDOR_FLAG is set"
#endif
}
