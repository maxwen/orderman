add_lunch_combo om_imx8-eng
add_lunch_combo om_imx8-userdebug

