package com.pluscubed.logcat.intents;

public class Intents {

    public static final String ACTION_LAUNCH = "com.pluscubed.logcat.intents.LAUNCH";
    public static final String EXTRA_FILTER = "filter";
    public static final String EXTRA_LEVEL = "level";

}
