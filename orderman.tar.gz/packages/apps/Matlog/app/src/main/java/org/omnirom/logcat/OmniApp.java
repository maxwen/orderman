package org.omnirom.logcat;

import android.app.Application;

public class OmniApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
    }
}
